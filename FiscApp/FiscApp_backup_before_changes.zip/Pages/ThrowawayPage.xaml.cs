using FiscApp.Services;

namespace FiscApp.Pages;

/// <summary>
/// Scratch/test page (opened from the gray TEST button on MainPage). Shows how many
/// transactions and goals are in the shared FinanceDataStore. Not part of the real app flow.
/// </summary>
public partial class ThrowawayPage : ContentPage
{
	private readonly FinanceDataStore store;
	public ThrowawayPage(FinanceDataStore store)
	{
		this.store = store;
		InitializeComponent();
		ShowTransactionCount();
		ShowGoalCount();
	}

	// Counts are read once when the page is built; they don't update live if data changes.
	public void ShowTransactionCount()
	{
		TransactionCountLabel.Text = $"{store.Transactions.Count}";
	}

    public void ShowGoalCount()
    {
        GoalCountLabel.Text = $"{store.Goals.Count}";
    }
}